package com.test.dto;

public class VwOpenCourseWithSubjectDTO {
	
	private String opencourseSeq;
	private String courseName;
	private String classroomName;
	private String openSubjectSeq;
	private String subjectName;
	private String openSubjectStartDate;
	private String openSubjectEndDate;
	private String textbookName;
	private String teacherName;
	private String whetherGrade;
	private String whetherExam;
	
	public String getOpencourseSeq() {
		return opencourseSeq;
	}
	public void setOpencourseSeq(String opencourseSeq) {
		this.opencourseSeq = opencourseSeq;
	}
	public String getCourseName() {
		return courseName;
	}
	public void setCourseName(String courseName) {
		this.courseName = courseName;
	}
	public String getClassroomName() {
		return classroomName;
	}
	public void setClassroomName(String classroomName) {
		this.classroomName = classroomName;
	}
	public String getSubjectName() {
		return subjectName;
	}
	public void setSubjectName(String subjectName) {
		this.subjectName = subjectName;
	}
	public String getOpenSubjectStartDate() {
		return openSubjectStartDate;
	}
	public void setOpenSubjectStartDate(String openSubjectStartDate) {
		this.openSubjectStartDate = openSubjectStartDate;
	}
	public String getOpenSubjectEndDate() {
		return openSubjectEndDate;
	}
	public void setOpenSubjectEndDate(String openSubjectEndDate) {
		this.openSubjectEndDate = openSubjectEndDate;
	}
	public String getTextbookName() {
		return textbookName;
	}
	public void setTextbookName(String textbookName) {
		this.textbookName = textbookName;
	}
	public String getTeacherName() {
		return teacherName;
	}
	public void setTeacherName(String teacherName) {
		this.teacherName = teacherName;
	}
	public String getWhetherGrade() {
		return whetherGrade;
	}
	public void setWhetherGrade(String whetherGrade) {
		this.whetherGrade = whetherGrade;
	}
	public String getWhetherExam() {
		return whetherExam;
	}
	public void setWhetherExam(String whetherExam) {
		this.whetherExam = whetherExam;
	}
	public String getOpenSubjectSeq() {
		return openSubjectSeq;
	}
	public void setOpenSubjectSeq(String openSubjectSeq) {
		this.openSubjectSeq = openSubjectSeq;
	}
	
}
