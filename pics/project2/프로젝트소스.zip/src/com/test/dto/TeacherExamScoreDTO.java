package com.test.dto;

public class TeacherExamScoreDTO {
	
	
	private String seq;
	private String signUpSeq;
	private String openSubjectSeq;
	private String writtenScore;
	private String attendanceScore;
	private String practicalScore;
	
	
	public String getSeq() {
		return seq;
	}
	public void setSeq(String seq) {
		this.seq = seq;
	}
	public String getSignUpSeq() {
		return signUpSeq;
	}
	public void setSignUpSeq(String signUpSeq) {
		this.signUpSeq = signUpSeq;
	}
	public String getOpenSubjectSeq() {
		return openSubjectSeq;
	}
	public void setOpenSubjectSeq(String openSubjectSeq) {
		this.openSubjectSeq = openSubjectSeq;
	}
	public String getWrittenScore() {
		return writtenScore;
	}
	public void setWrittenScore(String writtenScore) {
		this.writtenScore = writtenScore;
	}
	public String getAttendanceScore() {
		return attendanceScore;
	}
	public void setAttendanceScore(String attendanceScore) {
		this.attendanceScore = attendanceScore;
	}
	public String getPracticalScore() {
		return practicalScore;
	}
	public void setPracticalScore(String practicalScore) {
		this.practicalScore = practicalScore;
	}
	
	
}
