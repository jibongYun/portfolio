package com.test.dto;

public class VwOneStudentDTO {

	private String signUpSeq;
	private String courseName;
	private String openCourseStartDate;
	private String openCourseEndDate;
	private String classroomName;
	private String signUpStatus;
	private String signUpEnddate;
	
	public String getSignUpSeq() {
		return signUpSeq;
	}
	public void setSignUpSeq(String signUpSeq) {
		this.signUpSeq = signUpSeq;
	}
	public String getCourseName() {
		return courseName;
	}
	public void setCourseName(String courseName) {
		this.courseName = courseName;
	}
	public String getOpenCourseStartDate() {
		return openCourseStartDate;
	}
	public void setOpenCourseStartDate(String openCourseStartDate) {
		this.openCourseStartDate = openCourseStartDate;
	}
	public String getOpenCourseEndDate() {
		return openCourseEndDate;
	}
	public void setOpenCourseEndDate(String openCourseEndDate) {
		this.openCourseEndDate = openCourseEndDate;
	}
	public String getClassroomName() {
		return classroomName;
	}
	public void setClassroomName(String classroomName) {
		this.classroomName = classroomName;
	}
	public String getSignUpStatus() {
		return signUpStatus;
	}
	public void setSignUpStatus(String signUpStatus) {
		this.signUpStatus = signUpStatus;
	}
	public String getSignUpEnddate() {
		return signUpEnddate;
	}
	public void setSignUpEnddate(String signUpEnddate) {
		this.signUpEnddate = signUpEnddate;
	}
	
}
