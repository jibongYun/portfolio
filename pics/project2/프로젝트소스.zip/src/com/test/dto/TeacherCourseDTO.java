package com.test.dto;

public class TeacherCourseDTO {

	private String seq;
	private String name;	
	private String start;
	private String end;	
	private String rigst;

	
	public String getSeq() {
		return seq;
	}

	public void setSeq(String seq) {
		this.seq = seq;
	}

	
	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getStart() {
		return start;
	}

	public void setStart(String start) {
		this.start = start;
	}

	public String getEnd() {
		return end;
	}

	public void setEnd(String end) {
		this.end = end;
	}

	public String getRigst() {
		return rigst;
	}

	public void setRigst(String rigst) {
		this.rigst = rigst;
	}
	
	
}
