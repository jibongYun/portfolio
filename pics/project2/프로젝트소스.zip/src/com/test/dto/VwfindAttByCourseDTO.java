package com.test.dto;

public class VwfindAttByCourseDTO {

	private String studentSeq;
	private String studentName;
	private String attendanceCount;
	private String tardyCount;
	private String earlyLeaveCount;
	private String leavingCount;
	private String sickLeaveCount;
	private String absentCount;
	
	public String getStudentSeq() {
		return studentSeq;
	}
	public void setStudentSeq(String studentSeq) {
		this.studentSeq = studentSeq;
	}
	public String getStudentName() {
		return studentName;
	}
	public void setStudentName(String studentName) {
		this.studentName = studentName;
	}
	public String getAttendanceCount() {
		return attendanceCount;
	}
	public void setAttendanceCount(String attendanceCount) {
		this.attendanceCount = attendanceCount;
	}
	public String getTardyCount() {
		return tardyCount;
	}
	public void setTardyCount(String tardyCount) {
		this.tardyCount = tardyCount;
	}
	public String getEarlyLeaveCount() {
		return earlyLeaveCount;
	}
	public void setEarlyLeaveCount(String earlyLeaveCount) {
		this.earlyLeaveCount = earlyLeaveCount;
	}
	public String getLeavingCount() {
		return leavingCount;
	}
	public void setLeavingCount(String leavingCount) {
		this.leavingCount = leavingCount;
	}
	public String getSickLeaveCount() {
		return sickLeaveCount;
	}
	public void setSickLeaveCount(String sickLeaveCount) {
		this.sickLeaveCount = sickLeaveCount;
	}
	public String getAbsentCount() {
		return absentCount;
	}
	public void setAbsentCount(String absentCount) {
		this.absentCount = absentCount;
	}
	
}
