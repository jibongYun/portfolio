package com.test.dto;

public class VwFindGradeBySubjectDTO {

	private String openSubjectSeq;
	private String subjectName;
	private String teacherName;
	private String textbookName;
	private String studentName;
	private String studentSsn;
	private String attendanceScore;
	private String writtenScore;
	private String practicalScore;
	private String studentSeq;
	private String courseName;
	private String openCourseStartDate;
	private String openCourseEndDate;
	
	public String getOpenSubjectSeq() {
		return openSubjectSeq;
	}
	public void setOpenSubjectSeq(String openSubjectSeq) {
		this.openSubjectSeq = openSubjectSeq;
	}
	public String getSubjectName() {
		return subjectName;
	}
	public void setSubjectName(String subjectName) {
		this.subjectName = subjectName;
	}
	public String getTeacherName() {
		return teacherName;
	}
	public void setTeacherName(String teacherName) {
		this.teacherName = teacherName;
	}
	public String getTextbookName() {
		return textbookName;
	}
	public void setTextbookName(String textbookName) {
		this.textbookName = textbookName;
	}
	public String getStudentName() {
		return studentName;
	}
	public void setStudentName(String studentName) {
		this.studentName = studentName;
	}
	public String getStudentSsn() {
		return studentSsn;
	}
	public void setStudentSsn(String studentSsn) {
		this.studentSsn = studentSsn;
	}
	public String getAttendanceScore() {
		return attendanceScore;
	}
	public void setAttendanceScore(String attendanceScore) {
		this.attendanceScore = attendanceScore;
	}
	public String getWrittenScore() {
		return writtenScore;
	}
	public void setWrittenScore(String writtenScore) {
		this.writtenScore = writtenScore;
	}
	public String getPracticalScore() {
		return practicalScore;
	}
	public void setPracticalScore(String practicalScore) {
		this.practicalScore = practicalScore;
	}
	public String getStudentSeq() {
		return studentSeq;
	}
	public void setStudentSeq(String studentSeq) {
		this.studentSeq = studentSeq;
	}
	public String getCourseName() {
		return courseName;
	}
	public void setCourseName(String courseName) {
		this.courseName = courseName;
	}
	public String getOpenCourseStartDate() {
		return openCourseStartDate;
	}
	public void setOpenCourseStartDate(String openCourseStartDate) {
		this.openCourseStartDate = openCourseStartDate;
	}
	public String getOpenCourseEndDate() {
		return openCourseEndDate;
	}
	public void setOpenCourseEndDate(String openCourseEndDate) {
		this.openCourseEndDate = openCourseEndDate;
	}
	
}
