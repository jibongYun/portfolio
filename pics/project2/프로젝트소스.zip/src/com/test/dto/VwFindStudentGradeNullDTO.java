package com.test.dto;

public class VwFindStudentGradeNullDTO {
/*
 *openSubjectSeq(개설과목번호), openCourseSeq(개설과정번호), 
 *signUpseq(수강번호),CouseName(과정명), subjectName(과목명), 
 *studentName(교육생명), ssn(뒷자리), attendanceScore(출석성적),  
 *writtenScore(필기성적), practicalScore(실기성적), whetherexam(시험등록여부), 
 *whethergrade(성적등록여부), attendancePoint(출석배점), writtenPoint(필기배점), 
 *practicalPoint(실기배점), startdate(개설과목의시작일), enddate(개설과목의종료일) 
 *
 */
	
	private String openSubjectSeq;
	private String openCourseSeq;
	private String signUpseq;
	private String CourseName;
	private String SubjectName;
	private String studentName;
	private String ssn;
	private String attendanceScore;
	private String writtenScore;
	private String practicalScore;
	private String whetherexam;
	private String whethergrade;
	private String attendancePoint;
	private String writtenPoint;
	private String practicalPoint;
	private String startdate;
	private String enddate;
	public String getOpenSubjectSeq() {
		return openSubjectSeq;
	}
	public void setOpenSubjectSeq(String openSubjectSeq) {
		this.openSubjectSeq = openSubjectSeq;
	}
	public String getOpenCourseSeq() {
		return openCourseSeq;
	}
	public void setOpenCourseSeq(String openCourseSeq) {
		this.openCourseSeq = openCourseSeq;
	}
	public String getSignUpseq() {
		return signUpseq;
	}
	public void setSignUpseq(String signUpseq) {
		this.signUpseq = signUpseq;
	}
	public String getCourseName() {
		return CourseName;
	}
	public void setCourseName(String courseName) {
		CourseName = courseName;
	}
	public String getSubjectName() {
		return SubjectName;
	}
	public void setSubjectName(String subjectName) {
		SubjectName = subjectName;
	}
	public String getStudentName() {
		return studentName;
	}
	public void setStudentName(String studentName) {
		this.studentName = studentName;
	}
	public String getSsn() {
		return ssn;
	}
	public void setSsn(String ssn) {
		this.ssn = ssn;
	}
	public String getAttendanceScore() {
		return attendanceScore;
	}
	public void setAttendanceScore(String attendanceScore) {
		this.attendanceScore = attendanceScore;
	}
	public String getWrittenScore() {
		return writtenScore;
	}
	public void setWrittenScore(String writtenScore) {
		this.writtenScore = writtenScore;
	}
	public String getPracticalScore() {
		return practicalScore;
	}
	public void setPracticalScore(String practicalScore) {
		this.practicalScore = practicalScore;
	}
	public String getWhetherexam() {
		return whetherexam;
	}
	public void setWhetherexam(String whetherexam) {
		this.whetherexam = whetherexam;
	}
	public String getWhethergrade() {
		return whethergrade;
	}
	public void setWhethergrade(String whethergrade) {
		this.whethergrade = whethergrade;
	}
	public String getAttendancePoint() {
		return attendancePoint;
	}
	public void setAttendancePoint(String attendancePoint) {
		this.attendancePoint = attendancePoint;
	}
	public String getWrittenPoint() {
		return writtenPoint;
	}
	public void setWrittenPoint(String writtenPoint) {
		this.writtenPoint = writtenPoint;
	}
	public String getPracticalPoint() {
		return practicalPoint;
	}
	public void setPracticalPoint(String practicalPoint) {
		this.practicalPoint = practicalPoint;
	}
	public String getStartdate() {
		return startdate;
	}
	public void setStartdate(String startdate) {
		this.startdate = startdate;
	}
	public String getEnddate() {
		return enddate;
	}
	public void setEnddate(String enddate) {
		this.enddate = enddate;
	}
	

	
}
