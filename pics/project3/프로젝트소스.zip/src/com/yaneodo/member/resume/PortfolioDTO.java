package com.yaneodo.member.resume;

public class PortfolioDTO {

	private String portfolioseq;
	private String resumeseq;
	private String url;
	private String filename;
	private String orgfilename;
	
	public String getPortfolioseq() {
		return portfolioseq;
	}
	public void setPortfolioseq(String portfolioseq) {
		this.portfolioseq = portfolioseq;
	}
	public String getResumeseq() {
		return resumeseq;
	}
	public void setResumeseq(String resumeseq) {
		this.resumeseq = resumeseq;
	}
	public String getUrl() {
		return url;
	}
	public void setUrl(String url) {
		this.url = url;
	}
	public String getFilename() {
		return filename;
	}
	public void setFilename(String filename) {
		this.filename = filename;
	}
	public String getOrgfilename() {
		return orgfilename;
	}
	public void setOrgfilename(String orgfilename) {
		this.orgfilename = orgfilename;
	}

	
	
}
