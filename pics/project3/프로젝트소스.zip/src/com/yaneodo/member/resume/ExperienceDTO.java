package com.yaneodo.member.resume;

public class ExperienceDTO {

	private String experienceseq;
	private String resumeseq;
	private String company;
	private String field;
	private String job;
	private String startdate;
	private String enddate;
	
	public String getExperienceseq() {
		return experienceseq;
	}
	public void setExperienceseq(String experienceseq) {
		this.experienceseq = experienceseq;
	}
	public String getResumeseq() {
		return resumeseq;
	}
	public void setResumeseq(String resumeseq) {
		this.resumeseq = resumeseq;
	}
	public String getCompany() {
		return company;
	}
	public void setCompany(String company) {
		this.company = company;
	}
	public String getField() {
		return field;
	}
	public void setField(String field) {
		this.field = field;
	}
	public String getJob() {
		return job;
	}
	public void setJob(String job) {
		this.job = job;
	}
	public String getStartdate() {
		return startdate;
	}
	public void setStartdate(String startdate) {
		this.startdate = startdate;
	}
	public String getEnddate() {
		return enddate;
	}
	public void setEnddate(String enddate) {
		this.enddate = enddate;
	}
	
	
}
