package com.yaneodo.member.resume;

public class TrainingDTO {

	private String trainingseq;
	private String resumeseq;
	private String type;
	private String name;
	private String startDate;
	private String enddate;
	private String agency;
	
	public String getTrainingseq() {
		return trainingseq;
	}
	public void setTrainingseq(String trainingseq) {
		this.trainingseq = trainingseq;
	}
	public String getResumeseq() {
		return resumeseq;
	}
	public void setResumeseq(String resumeseq) {
		this.resumeseq = resumeseq;
	}
	public String getType() {
		return type;
	}
	public void setType(String type) {
		this.type = type;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getStartDate() {
		return startDate;
	}
	public void setStartDate(String startDate) {
		this.startDate = startDate;
	}
	public String getEnddate() {
		return enddate;
	}
	public void setEnddate(String enddate) {
		this.enddate = enddate;
	}
	public String getAgency() {
		return agency;
	}
	public void setAgency(String agency) {
		this.agency = agency;
	}
	
	
	
}
