package com.yaneodo.member.resume;

public class LanguageDTO {

	private String languageseq;
	private String resumeseq;
	private String languagetype;
	private String grade;
	
	public String getLanguageseq() {
		return languageseq;
	}
	public void setLanguageseq(String languageseq) {
		this.languageseq = languageseq;
	}
	public String getResumeseq() {
		return resumeseq;
	}
	public void setResumeseq(String resumeseq) {
		this.resumeseq = resumeseq;
	}
	public String getLanguagetype() {
		return languagetype;
	}
	public void setLanguagetype(String languagetype) {
		this.languagetype = languagetype;
	}
	public String getGrade() {
		return grade;
	}
	public void setGrade(String grade) {
		this.grade = grade;
	}
	
	
}
