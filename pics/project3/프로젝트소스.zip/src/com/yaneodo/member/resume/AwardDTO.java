package com.yaneodo.member.resume;

public class AwardDTO {

	private String awardseq;
	private String resumeSeq;
	private String awardname;
	private String getdate;
	private String agency;
	
	public String getAwardseq() {
		return awardseq;
	}
	public void setAwardseq(String awardseq) {
		this.awardseq = awardseq;
	}
	public String getResumeSeq() {
		return resumeSeq;
	}
	public void setResumeSeq(String resumeSeq) {
		this.resumeSeq = resumeSeq;
	}
	public String getAwardname() {
		return awardname;
	}
	public void setAwardname(String awardname) {
		this.awardname = awardname;
	}
	public String getGetdate() {
		return getdate;
	}
	public void setGetdate(String getdate) {
		this.getdate = getdate;
	}
	public String getAgency() {
		return agency;
	}
	public void setAgency(String agency) {
		this.agency = agency;
	}
	
	
}
