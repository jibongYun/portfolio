package com.yaneodo.member.resume;

public class EducationDTO {
	
	private String educationseq;
	private String resumeseq;
	private String schooltype;
	private String schoolname;
	private String major;
	private String startdate;
	private String enddate;
	private String state;
	
	public String getEducationseq() {
		return educationseq;
	}
	public void setEducationseq(String educationseq) {
		this.educationseq = educationseq;
	}
	public String getResumeseq() {
		return resumeseq;
	}
	public void setResumeseq(String resumeseq) {
		this.resumeseq = resumeseq;
	}
	public String getSchooltype() {
		return schooltype;
	}
	public void setSchooltype(String schooltype) {
		this.schooltype = schooltype;
	}
	public String getSchoolname() {
		return schoolname;
	}
	public void setSchoolname(String schoolname) {
		this.schoolname = schoolname;
	}
	public String getMajor() {
		return major;
	}
	public void setMajor(String major) {
		this.major = major;
	}
	public String getStartdate() {
		return startdate;
	}
	public void setStartdate(String startdate) {
		this.startdate = startdate;
	}
	public String getEnddate() {
		return enddate;
	}
	public void setEnddate(String enddate) {
		this.enddate = enddate;
	}
	public String getState() {
		return state;
	}
	public void setState(String state) {
		this.state = state;
	}
	
	
}
