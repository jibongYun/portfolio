package com.yaneodo.member.resume;

public class CertificateDTO {
	
	private String certificateseq;
	private String resumeseq;
	private String type;
	private String grade;
	private String getdate;
	private String agency;
	
	public String getCertificateseq() {
		return certificateseq;
	}
	public void setCertificateseq(String certificateseq) {
		this.certificateseq = certificateseq;
	}
	public String getResumeseq() {
		return resumeseq;
	}
	public void setResumeseq(String resumeseq) {
		this.resumeseq = resumeseq;
	}
	public String getType() {
		return type;
	}
	public void setType(String type) {
		this.type = type;
	}
	public String getGrade() {
		return grade;
	}
	public void setGrade(String grade) {
		this.grade = grade;
	}
	public String getGetdate() {
		return getdate;
	}
	public void setGetdate(String getdate) {
		this.getdate = getdate;
	}
	public String getAgency() {
		return agency;
	}
	public void setAgency(String agency) {
		this.agency = agency;
	}
	
	

}
