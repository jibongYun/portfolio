package com.yaneodo.member.resume;

public class PreferenceDTO {

	private String preferenceseq;
	private String resumeseq;
	private String type;
	private String note;
	
	public String getPreferenceseq() {
		return preferenceseq;
	}
	public void setPreferenceseq(String preferenceseq) {
		this.preferenceseq = preferenceseq;
	}
	public String getResumeseq() {
		return resumeseq;
	}
	public void setResumeseq(String resumeseq) {
		this.resumeseq = resumeseq;
	}
	public String getType() {
		return type;
	}
	public void setType(String type) {
		this.type = type;
	}
	public String getNote() {
		return note;
	}
	public void setNote(String note) {
		this.note = note;
	}
	
	
}
