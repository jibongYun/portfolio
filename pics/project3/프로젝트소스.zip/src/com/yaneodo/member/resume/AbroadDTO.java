package com.yaneodo.member.resume;

public class AbroadDTO {
	
	private String abroadseq;
	private String resumeseq;
	private String type;
	private String country;
	private String startDate;
	private String endDate;
	private String note;
	
	public String getAbroadseq() {
		return abroadseq;
	}
	public void setAbroadseq(String abroadseq) {
		this.abroadseq = abroadseq;
	}
	public String getResumeseq() {
		return resumeseq;
	}
	public void setResumeseq(String resumeseq) {
		this.resumeseq = resumeseq;
	}
	public String getType() {
		return type;
	}
	public void setType(String type) {
		this.type = type;
	}
	public String getCountry() {
		return country;
	}
	public void setCountry(String country) {
		this.country = country;
	}
	public String getStartDate() {
		return startDate;
	}
	public void setStartDate(String startDate) {
		this.startDate = startDate;
	}
	public String getEndDate() {
		return endDate;
	}
	public void setEndDate(String endDate) {
		this.endDate = endDate;
	}
	public String getNote() {
		return note;
	}
	public void setNote(String note) {
		this.note = note;
	}
	
	
}
