package com.yaneodo.company.match;

public class ResumeReadDTO {

	private String resumereadseq;
	private String profileseq;
	private String companymemberseq;
	private String readdate;
	
	public String getResumereadseq() {
		return resumereadseq;
	}
	public void setResumereadseq(String resumereadseq) {
		this.resumereadseq = resumereadseq;
	}
	public String getProfileseq() {
		return profileseq;
	}
	public void setProfileseq(String profileseq) {
		this.profileseq = profileseq;
	}
	public String getCompanymemberseq() {
		return companymemberseq;
	}
	public void setCompanymemberseq(String companymemberseq) {
		this.companymemberseq = companymemberseq;
	}
	public String getReaddate() {
		return readdate;
	}
	public void setReaddate(String readdate) {
		this.readdate = readdate;
	}
	
	
}
