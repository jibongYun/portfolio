package com.yaneodo.company.match;

public class DibsDTO {

	private String dibsseq;
	private String profileseq;
	private String companyMemberseq;
	private String dibdate;
	
	public String getDibsseq() {
		return dibsseq;
	}
	public void setDibsseq(String dibsseq) {
		this.dibsseq = dibsseq;
	}
	public String getProfileseq() {
		return profileseq;
	}
	public void setProfileseq(String profileseq) {
		this.profileseq = profileseq;
	}
	public String getCompanyMemberseq() {
		return companyMemberseq;
	}
	public void setCompanyMemberseq(String companyMemberseq) {
		this.companyMemberseq = companyMemberseq;
	}
	public String getDibdate() {
		return dibdate;
	}
	public void setDibdate(String dibdate) {
		this.dibdate = dibdate;
	}
	
	
}
