package com.yaneodo.company.main;

public class CmemberDTO {

	private String companyMemberSeq;
	private String managerName;
	private String managerPhone;
	private String email;
	private String password;
	private String state;
	private String pass;
	
	public String getCompanyMemberSeq() {
		return companyMemberSeq;
	}
	public void setCompanyMemberSeq(String companyMemberSeq) {
		this.companyMemberSeq = companyMemberSeq;
	}
	public String getManagerName() {
		return managerName;
	}
	public void setManagerName(String managerName) {
		this.managerName = managerName;
	}
	public String getManagerPhone() {
		return managerPhone;
	}
	public void setManagerPhone(String managerPhone) {
		this.managerPhone = managerPhone;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public String getState() {
		return state;
	}
	public void setState(String state) {
		this.state = state;
	}
	public String getPass() {
		return pass;
	}
	public void setPass(String pass) {
		this.pass = pass;
	}
	
	
	
}
