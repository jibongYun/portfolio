package com.yaneodo.admin.jobtype;

public class JobtypeDTO {

	private String seq;
	private String jobtype;
	
	
	
	
	
	public String getSeq() {
		return seq;
	}
	public void setSeq(String seq) {
		this.seq = seq;
	}
	public String getJobtype() {
		return jobtype;
	}
	public void setJobtype(String jobtype) {
		this.jobtype = jobtype;
	}
	
	
	
}
