package com.yaneodo.admin.board;

public class BusinessDTO {

}
