package com.yaneodo.admin.service;

public class ServiceDAO {

}
