package com.yaneodo.admin.tag;

public class TagDTO {

	private String seq;
	private String title; //ctitle
	private String ttitle; //ttitle
	
	
	
	
	
	public String getTtitle() {
		return ttitle;
	}
	public void setTtitle(String ttitle) {
		this.ttitle = ttitle;
	}
	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	public String getSeq() {
		return seq;
	}
	public void setSeq(String seq) {
		this.seq = seq;
	}

	
	
	
	
}
